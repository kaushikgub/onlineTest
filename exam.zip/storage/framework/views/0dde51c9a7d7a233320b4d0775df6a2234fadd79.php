<?php $__env->startSection('body'); ?>
    <p class="text-center text-primary font-italic">Please be connected with this Student. They want to buy your packages :)</p>
    <table class="table">
        <thead>
        <tr class="bg-success text-white">
            <th scope="col">Sl.No.</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Mobile No</th>
            <th scope="col">Alternative No</th>
            <th scope="col">Package Name</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <input type="hidden" value="<?php echo e($a=1); ?>">
        <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-bottom border-light">
                <th scope="row"><?php echo e($a++); ?></th>
                <td><?php echo e($package->name); ?></td>
                <td><?php echo e($package->email); ?></td>
                <td><?php echo e($package->mobile_no); ?></td>
                <td><?php echo e($package->alternative_no); ?></td>
                <td><?php echo e($package->package_name); ?></td>
                <td><a class=" btn btn-danger w-100" href="<?php echo e(url('/admin/request-package-delete/'.$package->id)); ?>">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>