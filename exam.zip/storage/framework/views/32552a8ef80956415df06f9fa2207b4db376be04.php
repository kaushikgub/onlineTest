<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <p class="text-center font-italic">All Request For Password Change</p>
        <table class="table">
            <thead>
            <tr class="bg-success text-white">
                <th class="" scope="col">SL.No</th>
                <th class="" scope="col">Name</th>
                <th class="" scope="col">Email</th>
                <th class="" scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <input type="hidden" value="<?php echo e($a=0); ?>">
            <?php $__currentLoopData = $r_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-bottom border-dark">
                    <th class="" scope="row"><?php echo e($a=$a+1); ?></th>
                    <th class="" scope="row"><?php echo e($r_all->name); ?></th>
                    <td class=""><?php echo e($r_all->email); ?></td>
                    <td class=""><a href="<?php echo e(url('admin/s-c-p/'.$r_all->id)); ?>" class="btn btn-danger">Change</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>