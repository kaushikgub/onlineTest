<?php $__env->startSection('body'); ?>
    <div class="table-responsive"  style="overflow-x:auto;display: block !important;">
        <table class="table">
            <thead>
            <tr class="bg-success text-white">
                <th scope="col">Package</th>
                <th scope="col">Feedbacks</th>
            </tr>
            </thead>
            <tbody>
                <tr class="border-bottom border-dark">
                    <th scope="row">
                        <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($package->name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </th>

                    <th scope="row">
                        <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($feedback->rating); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </th>
                </tr>
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>