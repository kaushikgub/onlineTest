<?php $__env->startSection('body'); ?>
    <div class="table-responsive"  style="overflow-x:auto;display: block !important;">
        <table class="table">
            <thead>
            <tr class="bg-success text-white">
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Mobile No</th>
                <th scope="col">Address</th>
                <th scope="col">Exam</th>
                <th scope="col">College</th>
                <th scope="col">Year</th>
                <th scope="col">Action</th>
                <th scope="col">Details</th>
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-bottom border-dark">
                    <th scope="row"><?php echo e($student->name); ?></th>
                    <td><?php echo e($student->email); ?></td>
                    <td><?php echo e($student->mobile_no); ?></td>
                    <td><?php echo e($student->address); ?></td>
                    <td><?php echo e($student->exam); ?></td>
                    <td><?php echo e($student->college_name); ?></td>
                    <td><?php echo e($student->passing_year); ?></td>
                    <td><a class=" btn btn-danger w-100" href="<?php echo e(url('/admin/delete/'.$student->id)); ?>">Delete</a></td>
                    <td><a class=" btn btn-info w-100" href="<?php echo e(url('/admin/details/'.$student->id)); ?>">Details</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>