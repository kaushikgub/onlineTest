<?php $__env->startSection('body'); ?>

	<h2 class="text-center text-info font-italic">My Profile</h2>

	<div class="container">
		<div class="row mt-4">
			<div class="col border rounded p-2 border-info mr-4 bg-light">
				<div class="row">
					<div class="col-md-4">
						<label>Name</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->name); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Father`s Name</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->father_name); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Email</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->email); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Mobile No</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->mobile_no); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Date of Birth</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->birth); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Address</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->address); ?></label>
					</div>
				</div>
			</div>
			<div class="col border rounded p-2 border-info ml-4">
				<div class="row">
					<div class="col-md-4">
						<label>Exam</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->exam); ?></label>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<label>Qualification</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->qualification); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>College Name</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->college_name); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Passing Year</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->passing_year); ?></label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>% of Marks</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->marks); ?> %</label>
					</div>
				</div>

				<div class="row">
					<div class="col-md-4">
						<label>Strem</label>
					</div>
					<div class="col-md-1">
						<label>: </label>
					</div>
					<div class="col-md-7">
						<label><?php echo e($student->strem); ?></label>
					</div>
				</div>
			</div>
		</div>

		<div class="row mt-5 text-center">
			<div class="col mr-4">
				<a class=" btn btn-warning w-100" href="<?php echo e(url('/student/update-info')); ?>">Update Info</a>
			</div>
			<div class="col ml-4">
				<a class=" btn btn-danger w-100" href="<?php echo e(url('/student/change-password')); ?>">Change Password</a>
			</div>
		</div>
	</div>
	
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>