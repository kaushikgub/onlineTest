<?php $__env->startSection('body'); ?>

    <h2 class="text-center text-success">Questions List</h2>
    <a class="btn btn-warning text-success" href="<?php echo e(url('admin/delete-user-questions')); ?>">Delete all Questions</a>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mt-5 border rounded border-info">
        <div class="col">
            <p>Mobile No: <?php echo e($questions->mobile_no); ?></p>
            <p>Course: <?php echo e($questions->course_name); ?></p>
            <p>Question: <?php echo e($questions->question); ?></p>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>