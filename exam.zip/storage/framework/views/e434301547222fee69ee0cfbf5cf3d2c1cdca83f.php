<?php $__env->startSection('body'); ?>
        <div class="row mt-5">
            <div class="col-md-4 border border-primary rounded mx-auto my-lg-auto p-3">
                <h5 class="text-center text-success font-italic">Password Change for Student</h5>
                <span id="s" class="text-danger"></span>
                <?php echo e(Form::open(array('url' => 'admin/student-change-password','onsubmit' => 'return validation()'))); ?>

                <input type="hidden" name="id" value="<?php echo e($id); ?>">
                <div class="form-row">
                    <div class="col mt-3">
                        <input id="password" class="form-control" type="password" name="password" placeholder="Enter Password" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col mt-3">
                        <input id="confirm_password" class="form-control" type="password" name="c-password" placeholder="Enter Conform Password" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col mt-3">
                        <input class="form-control btn btn-success" type="submit" value="Submit">
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>

    <script>
        function validation() {
            var p = document.getElementById('password').value;
            var p1 = document.getElementById('confirm_password').value;
            if (p!=p1) {
                document.getElementById('s').innerHTML="Enter The Same Password";
                return false;
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>