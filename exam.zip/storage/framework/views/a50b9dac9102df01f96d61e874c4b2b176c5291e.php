<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-6 mx-auto">
            <h3 class="text-center">Add Student as Premium</h3>
        </div>
    </div>
    <div class="container">
        <?php echo e(Form::open(array('url' => 'admin/add-premium'))); ?>

            <div class="row mt-5">
                <div class="col-md-6 mx-auto">
                    <div class="form-group">
                        <label class="form-label-group">Select Package</label>
                        <select name="package-id" class="form-control" required>
                            <option value="">Select Package</option>
                            <?php $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($package->id); ?>"><?php echo e($package->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-6 mx-auto">
                    <div class="form-group">
                        <label class="form-label-group">Select Student</label>
                        <select name="student-id" class="form-control" required>
                            <option value="">Select Student</option>
                            <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-md-6 mx-auto">
                    <input class="btn btn-success w-100" type="submit" value="Add Student to this Package">
                </div>
            </div>
        <?php echo e(Form::close()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>