<!DOCTYPE html>
<html>
<head>
    <title>CG Sarkari Exam</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>/css/exam-style.css">
    
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">CG Sarkari Exam</a>
    </nav>
</header>

<section class="section1">
    <div class="row row1">
        <div class="col-md-8">
            <h6>System Name:</h6>
            <h2>C001</h2>
            <p>Contract invigilator if the name and photograph<br> is not yours </p>
        </div>
        <div class="col-md-2">
            <h6>Candidate Name:</h6>
            <h2>John Smith</h2>
            <h6>Subject: Mock Exam</h6>
        </div>
        <div class="col-md-2">
            <img src="<?php echo e(asset('')); ?>/image/user.png">
        </div>
    </div>
</section>
<section>
    <div class="login-form border border-primary rounded">
        <div class="p-5">
            <?php echo e(Form::open(array('url' => ''))); ?>

            <div class="form-row">
                <div class="col mt-3">
                    <input class="form-control" type="email" placeholder="Enter Email">
                </div>
            </div>
            <div class="form-row">
                <div class="col mt-3">
                    <input class="form-control" type="password" placeholder="Enter Password">
                </div>
            </div>
            <div class="form-row">
                <div class="col mt-3">
                    <input class="form-control btn btn-success" type="submit" value="Submit">
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</section>

<footer>

</footer>
</body>
</html>