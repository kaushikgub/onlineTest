<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PackageRequest extends Model
{
    protected $table = 'request_package';
}
