<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TestName extends Model
{
    protected $table = 'test_name';
}
