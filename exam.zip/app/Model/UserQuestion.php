<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UserQuestion extends Model
{
    protected $table = 'user_questions';
}
