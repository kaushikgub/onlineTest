<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class FeedbackStudent extends Model
{
    protected $table = 'student_feedback';
}
