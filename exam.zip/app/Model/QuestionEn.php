<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class QuestionEn extends Model
{
    protected $table = 'questions_en';
}
