<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class QuestionHi extends Model
{
    protected $table = 'questions_hi';
}
