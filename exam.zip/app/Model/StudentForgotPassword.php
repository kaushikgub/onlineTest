<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StudentForgotPassword extends Model
{
    protected $table = 'student_forgot_password';
}
